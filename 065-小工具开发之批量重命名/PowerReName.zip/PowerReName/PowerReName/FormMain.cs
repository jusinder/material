﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace PowerReName
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", "http://www.bamn.cn");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = this.folderBrowserDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                this.textBox1.Text = this.folderBrowserDialog1.SelectedPath;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.label4.Text = string.Empty;

                if (string.IsNullOrEmpty(this.textBox1.Text.Trim()))
                {
                    this.label4.Text = "文件路径不能为空。";
                    return;
                }

                string name = this.textBox2.Text.Trim();
                if (string.IsNullOrEmpty(name))
                {
                    this.label4.Text = "文件名不能为空。";
                    return;
                }

                if (!name.Contains("{编号}"))
                {
                    this.label4.Text = "文件名没有包含占位符：{编号}。";
                    return;
                }

                char[] invalidChars = Path.GetInvalidFileNameChars();
                char[] nameChars = name.ToCharArray();
                for (int i = 0; i < invalidChars.Length; i++)
                {
                    for (int j = 0; j < nameChars.Length; j++)
                    {
                        if (invalidChars[i] == nameChars[j])
                        {
                            this.label4.Text = "文件名含有不合法的字符。";
                            return;
                        }
                    }
                }

                //遍历文件夹
                string path = this.textBox1.Text;
                DirectoryInfo directory = new DirectoryInfo(path);
                //判断路径是否存在
                if (!directory.Exists)
                {
                    this.label4.Text = "文件夹不存在。";
                    return;
                }

                FileInfo[] files = directory.GetFiles("*.*", SearchOption.TopDirectoryOnly);//只获取当前目录
                                                                                            //List<string> extensions = new List<string>();
                                                                                            //for (int i = 0; i < files.Length; i++)
                                                                                            //{
                                                                                            //    if (!extensions.Contains(files[i].Extension))
                                                                                            //    {
                                                                                            //        extensions.Add(files[i].Extension);
                                                                                            //    }
                                                                                            //}


                SortAsFileName(ref files);//按文件名排序（顺序）

                int len = files.Length.ToString().Length;

                for (int i = 0; i < files.Length; i++)
                {
                    FileInfo file = files[i];
                    file.MoveTo(file.Directory.FullName + "\\" + this.textBox2.Text.Trim().Replace("{编号}", (i + 1).ToString().PadLeft(len, '0')) + file.Extension + ".bamn");
                }

                //再把后缀改回来
                FileInfo[] files2 = directory.GetFiles("*.*", SearchOption.TopDirectoryOnly);//只获取当前目录

                SortAsFileNameReversed(ref files);//按文件名排序（顺序）

                for (int i = 0; i < files2.Length; i++)
                {
                    FileInfo file = files2[i];
                    file.MoveTo(file.FullName.Replace(".bamn", string.Empty));
                }
            }
            catch (Exception ex)
            {
                this.label4.Text = "发生错误，可能文件无权限。";
                return;
            }
        }

        /// <summary>
        /// C#按文件名排序（顺序）
        /// </summary>
        /// <param name="arrFi">待排序数组</param>
        private void SortAsFileName(ref FileInfo[] arrFi)
        {
            Array.Sort(arrFi, delegate (FileInfo x, FileInfo y) { return x.Name.CompareTo(y.Name); });
        }

        /// <summary>
        /// C#按文件名排序（倒序）
        /// </summary>
        /// <param name="arrFi">待排序数组</param>
        private void SortAsFileNameReversed(ref FileInfo[] arrFi)
        {
            Array.Sort(arrFi, delegate (FileInfo x, FileInfo y) { return y.Name.CompareTo(x.Name); });
        }

        /// <summary>
        /// C#按创建时间排序（顺序）
        /// </summary>
        /// <param name="arrFi">待排序数组</param>
        private void SortAsFileCreationTime(ref FileInfo[] arrFi)
        {
            Array.Sort(arrFi, delegate (FileInfo x, FileInfo y) { return x.CreationTime.CompareTo(y.CreationTime); });
        }

        /// <summary>
        /// C#按创建时间排序（倒序）
        /// </summary>
        /// <param name="arrFi">待排序数组</param>
        private void SortAsFileCreationTimeReversed(ref FileInfo[] arrFi)
        {
            Array.Sort(arrFi, delegate (FileInfo x, FileInfo y) { return y.CreationTime.CompareTo(x.CreationTime); });
        }
    }
}