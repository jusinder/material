﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TimeEnd
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            EventLog eventLog = new EventLog();
            eventLog.Log = "System";//日志的类型 有应用程序 系统 等等
            EventLogEntryCollection eventLogEntryCollection = eventLog.Entries;//获取事件日志的内容
            for (int i = eventLogEntryCollection.Count-1; i >= 0; i--)
            {
                if (eventLogEntryCollection[i].TimeGenerated < new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0))
                {
                    int index = i;
                    if (eventLogEntryCollection[i + 1]!=null)
                    {
                        index = i + 1;
                    }
                    this.labelOpenTime.Text = eventLogEntryCollection[index].TimeGenerated.ToString("yyyy-MM-dd HH:mm");
                    break;
                }
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", "http://www.bamn.cn");
        }
    }
}
